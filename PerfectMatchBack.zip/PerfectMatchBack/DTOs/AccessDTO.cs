﻿namespace PerfectMatchBack.DTOs
{
    public class AccessDTO
    {
        public int IdAccess { get; set; }

        public string Password { get; set; } = null!;
    }
}

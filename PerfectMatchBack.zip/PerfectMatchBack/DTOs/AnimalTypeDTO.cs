﻿namespace PerfectMatchBack.DTOs
{
    public class AnimalTypeDTO
    {
        public int IdAnimalType { get; set; }

        public string AnimalTypeName { get; set; } = null!;
    }
}

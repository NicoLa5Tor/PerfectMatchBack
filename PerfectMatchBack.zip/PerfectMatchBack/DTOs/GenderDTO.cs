﻿namespace PerfectMatchBack.DTOs
{
    public class GenderDTO
    {
        public int IdGender { get; set; }
        public string GenderName { get; set; } = null!;
    }
}

﻿namespace PerfectMatchBack.DTOs
{
    public class ImageDTO
    {
        public int IdImage { get; set; }
        public int IdPublication { get; set; }
        public string DataImage { get; set; } = null!;
    }
}

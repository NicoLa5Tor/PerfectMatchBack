﻿namespace PerfectMatchBack.DTOs
{
    public class RoleDTO
    {
        public int IdRole { get; set; }

        public string RoleName { get; set; } = null!;
    }
}

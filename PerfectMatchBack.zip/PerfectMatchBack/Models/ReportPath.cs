﻿using System;
using System.Collections.Generic;

namespace PerfectMatchBack.Models;

public partial class ReportPath
{
    public int IdReport { get; set; }

    public string? ReportName { get; set; }

    public string? Path { get; set; }
}
